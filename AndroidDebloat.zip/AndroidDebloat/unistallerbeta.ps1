Add-Type -AssemblyName System.Windows.Forms

# Ruta relativa a adb.exe (en la misma carpeta que el script)
$adbPath = Join-Path -Path (Split-Path -Parent $MyInvocation.MyCommand.Definition) -ChildPath "adb.exe"

# Función para comprobar si ADB está disponible y si hay un dispositivo conectado
function Check-ADB {
    if (-not (Test-Path $adbPath)) {
        Write-Host "Error: No se encontró adb.exe en la misma carpeta que el script." -ForegroundColor Red
        exit
    }

    $device = & $adbPath devices | Select-String -Pattern "device$" | Measure-Object
    if ($device.Count -eq 0) {
        Write-Host "Error: No hay dispositivos conectados." -ForegroundColor Red
        exit
    }
}

# Función para listar aplicaciones instaladas y clasificarlas como del sistema o del usuario
function List-Apps {
    Write-Host "Obteniendo lista de aplicaciones instaladas..." -ForegroundColor Cyan

    # Obtener listas de apps del sistema y de usuario
    $systemApps = & $adbPath shell pm list packages -s | ForEach-Object { $_ -replace "package:", "" }
    $userApps = & $adbPath shell pm list packages -3 | ForEach-Object { $_ -replace "package:", "" }

    # Verificar que las aplicaciones de usuario y sistema estén siendo recuperadas correctamente
    Write-Host "Aplicaciones del sistema: $($systemApps.Count)" -ForegroundColor Green
    Write-Host "Aplicaciones de usuario: $($userApps.Count)" -ForegroundColor Green

    # Combinar resultados y clasificar
    $allApps = @()
    foreach ($app in ($systemApps + $userApps | Sort-Object)) {
        $type = if ($systemApps -contains $app) { "Sistema" } else { "Usuario" }
        $allApps += [PSCustomObject]@{
            "Paquete" = $app
            "Tipo"    = $type
        }
    }

    return $allApps
}

# Función para eliminar una aplicación
function Remove-App {
    param (
        [string]$packageName
    )
    if (-not $packageName) {
        Write-Host "No se seleccionó ningún paquete para eliminar." -ForegroundColor Yellow
        return
    }

    Write-Host "Eliminando aplicación: ${packageName}..." -ForegroundColor Green
    $result = & $adbPath shell pm uninstall $packageName 2>&1  # Redirigimos errores a la salida estándar
    if ($result -match "Success") {
        Write-Host "La aplicación ${packageName} fue eliminada correctamente." -ForegroundColor Green
    } elseif ($result -match "Failure") {
        Write-Host "Error al eliminar la aplicación ${packageName}: $result" -ForegroundColor Red
    } else {
        Write-Host "Resultado inesperado al eliminar la aplicación ${packageName}: $result" -ForegroundColor Red
    }
}

# Función para mover aplicaciones entre listas
function Move-App {
    param (
        [System.Windows.Forms.ListBox]$sourceList,
        [System.Windows.Forms.ListBox]$destinationList
    )
    $selectedItem = $sourceList.SelectedItem
    if ($selectedItem -ne $null) {
        $destinationList.Items.Add($selectedItem)
        $sourceList.Items.Remove($selectedItem)
    }
}

# Función para desinstalar aplicaciones de la lista de eliminación
function Uninstall-SelectedApps {
    param (
        [System.Windows.Forms.ListBox]$appsToRemoveList
    )
    foreach ($app in $appsToRemoveList.Items) {
        # Extraer solo el nombre del paquete (eliminando el tipo de etiqueta)
        $packageName = $app -replace " \[.*\]", ""
        Remove-App -packageName $packageName
    }
}

# Crear el formulario
$form = New-Object System.Windows.Forms.Form
$form.Text = 'Administrador de Aplicaciones'
$form.Size = New-Object System.Drawing.Size(800, 500) # Aumentamos aún más el tamaño del formulario

# Crear el encabezado con el texto clicable
$headerLabel = New-Object System.Windows.Forms.Label
$headerLabel.Text = "Debloater Android - By TheKrowBlooder"
$headerLabel.Location = New-Object System.Drawing.Point(20, 20)
$headerLabel.Size = New-Object System.Drawing.Size(330, 30)
$headerLabel.Font = New-Object System.Drawing.Font("Arial", 12, [System.Drawing.FontStyle]::Bold)
$headerLabel.ForeColor = [System.Drawing.Color]::Blue

# Evento de clic para redirigir a tu canal de YouTube
$headerLabel.Add_Click({
    Start-Process "https://www.youtube.com/@TheKrowBlooder"
})

# Lista de aplicaciones disponibles
$availableAppsListBox = New-Object System.Windows.Forms.ListBox
$availableAppsListBox.Location = New-Object System.Drawing.Point(20, 100) # Ajuste de la ubicación
$availableAppsListBox.Size = New-Object System.Drawing.Size(300, 350) # Ajuste de tamaño
$availableAppsListBox.SelectionMode = [System.Windows.Forms.SelectionMode]::One

# Lista de aplicaciones a eliminar
$appsToRemoveListBox = New-Object System.Windows.Forms.ListBox
$appsToRemoveListBox.Location = New-Object System.Drawing.Point(460, 100) # Ajuste de la ubicación
$appsToRemoveListBox.Size = New-Object System.Drawing.Size(300, 350) # Ajuste de tamaño
$appsToRemoveListBox.SelectionMode = [System.Windows.Forms.SelectionMode]::One

# Cuadro de búsqueda
$searchBox = New-Object System.Windows.Forms.TextBox
$searchBox.Location = New-Object System.Drawing.Point(20, 65)
$searchBox.Size = New-Object System.Drawing.Size(300, 40) # Aumentar tamaño del cuadro de búsqueda

# Tooltip para el cuadro de búsqueda
$toolTip = New-Object System.Windows.Forms.ToolTip
$toolTip.SetToolTip($searchBox, "Escribe para buscar aplicaciones")

# Botón para mover aplicaciones a eliminar
$moveButton = New-Object System.Windows.Forms.Button
$moveButton.Location = New-Object System.Drawing.Point(330, 140) # Ajuste de la ubicación
$moveButton.Size = New-Object System.Drawing.Size(120, 40) # Aseguramos tamaño uniforme
$moveButton.Text = '>>'
$moveButton.Add_Click({
    Move-App -sourceList $availableAppsListBox -destinationList $appsToRemoveListBox
})

# Botón para mover aplicaciones de vuelta
$removeButton = New-Object System.Windows.Forms.Button
$removeButton.Location = New-Object System.Drawing.Point(330, 200) # Ajuste de la ubicación
$removeButton.Size = New-Object System.Drawing.Size(120, 40) # Aseguramos tamaño uniforme
$removeButton.Text = '<<'
$removeButton.Add_Click({
    Move-App -sourceList $appsToRemoveListBox -destinationList $availableAppsListBox
})

# Botón para desinstalar aplicaciones seleccionadas
$uninstallButton = New-Object System.Windows.Forms.Button
$uninstallButton.Location = New-Object System.Drawing.Point(330, 260) # Ajuste de la ubicación
$uninstallButton.Size = New-Object System.Drawing.Size(120, 40) # Aseguramos tamaño uniforme
$uninstallButton.Text = 'Desinstalar'
$uninstallButton.Add_Click({
    Uninstall-SelectedApps -appsToRemoveList $appsToRemoveListBox
    $appsToRemoveListBox.Items.Clear()
})

# Función para filtrar aplicaciones en la lista de disponibles conforme se escribe
$searchBox.Add_TextChanged({
    $filteredApps = $appsList | Where-Object { $_.Paquete -like "*$($searchBox.Text)*" }
    $availableAppsListBox.Items.Clear()
    foreach ($app in $filteredApps) {
        $availableAppsListBox.Items.Add("$($app.Paquete) [$($app.Tipo)]")  # Mostrar también el tipo
    }
})

# Cargar aplicaciones en la lista de disponibles
$appsList = List-Apps
foreach ($app in $appsList) {
    $availableAppsListBox.Items.Add("$($app.Paquete) [$($app.Tipo)]")  # Mostrar también el tipo
}

# Agregar controles al formulario
$form.Controls.Add($headerLabel)
$form.Controls.Add($availableAppsListBox)
$form.Controls.Add($appsToRemoveListBox)
$form.Controls.Add($moveButton)
$form.Controls.Add($removeButton)
$form.Controls.Add($uninstallButton)
$form.Controls.Add($searchBox)

# Mostrar el formulario
$form.ShowDialog()
