Add-Type -AssemblyName System.Windows.Forms

$adbPath = Join-Path -Path (Split-Path -Parent $MyInvocation.MyCommand.Definition) -ChildPath "adb.exe"

function Check-ADB {
    if (-not (Test-Path $adbPath)) {
        exit
    }

    $device = & $adbPath devices | Select-String -Pattern "device$" | Measure-Object
    if ($device.Count -eq 0) {
        exit
    }
}

function List-Apps {
    $systemApps = & $adbPath shell pm list packages -s | ForEach-Object { $_ -replace "package:", "" }
    $userApps = & $adbPath shell pm list packages -3 | ForEach-Object { $_ -replace "package:", "" }

    $allApps = @()
    foreach ($app in ($systemApps + $userApps | Sort-Object)) {
        $type = if ($systemApps -contains $app) { "Sistema" } else { "Usuario" }
        $allApps += [PSCustomObject]@{
            "Paquete" = $app
            "Tipo"    = $type
        }
    }

    return $allApps
}

function Remove-App {
    param (
        [string]$packageName,
        [string]$appType
    )
    if (-not $packageName) {
        return
    }

    if ($appType -eq "Sistema") {
        # Comando para desinstalar aplicaciones del sistema
        $result = & $adbPath shell pm uninstall -k --user 0 $packageName 2>&1
    } else {
        # Comando para desinstalar aplicaciones de usuario
        $result = & $adbPath shell pm uninstall $packageName 2>&1
    }

    if ($result -match "Success") {
        Write-Host "Aplicación $packageName desinstalada con éxito."
    } elseif ($result -match "Failure") {
        Write-Host "Error al desinstalar la aplicación $packageName."
    } else {
        Write-Host "Resultado inesperado: $result"
    }
}

function Move-App {
    param (
        [System.Windows.Forms.ListBox]$sourceList,
        [System.Windows.Forms.ListBox]$destinationList
    )
    $selectedItem = $sourceList.SelectedItem
    if ($selectedItem -ne $null) {
        $destinationList.Items.Add($selectedItem)
        $sourceList.Items.Remove($selectedItem)
    }
}

function Uninstall-SelectedApps {
    param (
        [System.Windows.Forms.ListBox]$appsToRemoveList
    )
    foreach ($app in $appsToRemoveList.Items) {
        $packageName = $app -replace " \[.*\]", ""   # Eliminar la etiqueta [Sistema] o [Usuario]
        $appType = if ($app -like "*Sistema*") { "Sistema" } else { "Usuario" }
        Remove-App -packageName $packageName -appType $appType
    }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Administrador de Aplicaciones'
$form.Size = New-Object System.Drawing.Size(800, 500)

$headerLabel = New-Object System.Windows.Forms.Label
$headerLabel.Text = "Debloater Android - By TheKrowBlooder"
$headerLabel.Location = New-Object System.Drawing.Point(20, 20)
$headerLabel.Size = New-Object System.Drawing.Size(330, 30)
$headerLabel.Font = New-Object System.Drawing.Font("Arial", 12, [System.Drawing.FontStyle]::Bold)
$headerLabel.ForeColor = [System.Drawing.Color]::Blue

$headerLabel.Add_Click({
    Start-Process "https://www.youtube.com/@TheKrowBlooder"
})

$availableAppsListBox = New-Object System.Windows.Forms.ListBox
$availableAppsListBox.Location = New-Object System.Drawing.Point(20, 100)
$availableAppsListBox.Size = New-Object System.Drawing.Size(300, 350)
$availableAppsListBox.SelectionMode = [System.Windows.Forms.SelectionMode]::One

$appsToRemoveListBox = New-Object System.Windows.Forms.ListBox
$appsToRemoveListBox.Location = New-Object System.Drawing.Point(460, 100)
$appsToRemoveListBox.Size = New-Object System.Drawing.Size(300, 350)
$appsToRemoveListBox.SelectionMode = [System.Windows.Forms.SelectionMode]::One

$searchBox = New-Object System.Windows.Forms.TextBox
$searchBox.Location = New-Object System.Drawing.Point(20, 65)
$searchBox.Size = New-Object System.Drawing.Size(300, 40)

$toolTip = New-Object System.Windows.Forms.ToolTip
$toolTip.SetToolTip($searchBox, "Escribe para buscar aplicaciones")

$moveButton = New-Object System.Windows.Forms.Button
$moveButton.Location = New-Object System.Drawing.Point(330, 140)
$moveButton.Size = New-Object System.Drawing.Size(120, 40)
$moveButton.Text = '>>'
$moveButton.Add_Click({
    Move-App -sourceList $availableAppsListBox -destinationList $appsToRemoveListBox
})

$removeButton = New-Object System.Windows.Forms.Button
$removeButton.Location = New-Object System.Drawing.Point(330, 200)
$removeButton.Size = New-Object System.Drawing.Size(120, 40)
$removeButton.Text = '<<'
$removeButton.Add_Click({
    Move-App -sourceList $appsToRemoveListBox -destinationList $availableAppsListBox
})

$uninstallButton = New-Object System.Windows.Forms.Button
$uninstallButton.Location = New-Object System.Drawing.Point(330, 260)
$uninstallButton.Size = New-Object System.Drawing.Size(120, 40)
$uninstallButton.Text = 'Desinstalar'
$uninstallButton.Add_Click({
    Uninstall-SelectedApps -appsToRemoveList $appsToRemoveListBox
    $appsToRemoveListBox.Items.Clear()
})

$searchBox.Add_TextChanged({
    $filteredApps = $appsList | Where-Object { $_.Paquete -like "*$($searchBox.Text)*" }
    $availableAppsListBox.Items.Clear()
    foreach ($app in $filteredApps) {
        $availableAppsListBox.Items.Add("$($app.Paquete) [$($app.Tipo)]")
    }
})

$appsList = List-Apps
foreach ($app in $appsList) {
    $availableAppsListBox.Items.Add("$($app.Paquete) [$($app.Tipo)]")
}

$form.Controls.Add($headerLabel)
$form.Controls.Add($availableAppsListBox)
$form.Controls.Add($appsToRemoveListBox)
$form.Controls.Add($moveButton)
$form.Controls.Add($removeButton)
$form.Controls.Add($uninstallButton)
$form.Controls.Add($searchBox)

$form.ShowDialog()
