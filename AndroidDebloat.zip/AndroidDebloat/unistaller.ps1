# Ruta relativa a adb.exe (en la misma carpeta que el script)
$adbPath = Join-Path -Path (Split-Path -Parent $MyInvocation.MyCommand.Definition) -ChildPath "adb.exe"

# Función para comprobar si ADB está disponible y si hay un dispositivo conectado
function Check-ADB {
    if (-not (Test-Path $adbPath)) {
        Write-Host "Error: No se encontró adb.exe en la misma carpeta que el script." -ForegroundColor Red
        exit
    }

    $device = & $adbPath devices | Select-String -Pattern "device$" | Measure-Object
    if ($device.Count -eq 0) {
        Write-Host "Error: No hay dispositivos conectados." -ForegroundColor Red
        exit
    }
}

# Función para listar aplicaciones instaladas y clasificarlas como del sistema o del usuario
function List-Apps {
    Write-Host "Obteniendo lista de aplicaciones instaladas..." -ForegroundColor Cyan

    # Obtener listas de apps del sistema y de usuario
    $systemApps = & $adbPath shell pm list packages -s | ForEach-Object { $_ -replace "package:", "" }
    $userApps = & $adbPath shell pm list packages -3 | ForEach-Object { $_ -replace "package:", "" }

    # Combinar resultados y clasificar
    $allApps = @()
    foreach ($app in ($systemApps + $userApps | Sort-Object)) {
        $type = if ($systemApps -contains $app) { "Sistema" } else { "Usuario" }
        $allApps += [PSCustomObject]@{
            "Paquete" = $app
            "Tipo"    = $type
        }
    }

    # Mostrar las aplicaciones en Out-GridView con selección múltiple
    $selectedApps = $allApps | Out-GridView -Title "Aplicaciones instaladas (selecciona para eliminar)" -PassThru

    return $selectedApps
}

# Función para eliminar una aplicación
function Remove-App {
    param (
        [string]$packageName
    )
    if (-not $packageName) {
        Write-Host "No se seleccionó ningún paquete para eliminar." -ForegroundColor Yellow
        return
    }

    Write-Host "Eliminando aplicación: ${packageName}..." -ForegroundColor Green
    $result = & $adbPath shell pm uninstall $packageName
    if ($result -match "Success") {
        Write-Host "La aplicación ${packageName} fue eliminada correctamente." -ForegroundColor Green
    } else {
        Write-Host "Error al eliminar la aplicación ${packageName}: ${result}" -ForegroundColor Red
    }
}

# Comprobar ADB y dispositivo
Check-ADB

# Listar aplicaciones y eliminar las seleccionadas
$appsToRemove = List-Apps
if ($appsToRemove) {
    Write-Host "nEliminando las aplicaciones seleccionadas..." -ForegroundColor Cyan
    foreach ($app in $appsToRemove) {
        Remove-App -packageName $app.Paquete
    }
} else {
    Write-Host "No se seleccionaron aplicaciones para eliminar." -ForegroundColor Yellow
}